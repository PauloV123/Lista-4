#include <iostream>

class IntegerSet {
  //declarando as funçoes publicas
public:
	IntegerSet();
	IntegerSet(IntegerSet &s);
	IntegerSet(int b[], int n);
	const IntegerSet &operator=(const IntegerSet &s);
	void insertElement(int n);
	void deleteElement(int n);
	void printSet();
	IntegerSet unionOfSets(IntegerSet s);
	IntegerSet intersectionOfSets(IntegerSet s);
	~IntegerSet();
	
	//declarando as funçoes privadas
private:
	int *p;
	int size;
};