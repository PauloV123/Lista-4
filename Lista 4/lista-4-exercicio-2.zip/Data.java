public class Data{
	private int dia;
	private int mes;
	private int ano;
	
	public Data(int oMes, int oDia, int anoPadrao){
		mes = checkMes(oMes);
		ano = anoPadrao;
		dia = checkDia(oDia);
		
		System.out.printf("Date object constructor for date %s\n", this);
	}
//---------------------------------------------------------------------
	public int checkMes(int testMes){
		if(testMes > 0 && testMes <= 12){
			return testMes;
		}
		else{
			System.out.printf("mes invalido (%d) setando para 1", testMes);
			return 1;
		}
	}
//---------------------------------------------------------------------
	public int checkDia(int testDia){
		int diaPorMes[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
		if(testDia > 0 && testDia <= diaPorMes[mes]){
			return testDia;
		}
			
		//para ano bissexto
		if (mes == 2 && testDia == 29 && (ano % 400 == 0 || (ano % 4 == 0 && ano % 100 != 0) ) ){
			return testDia;
		}
		
		System.out.printf("dia invalido (%d) setando para 1", testDia);
		return 1;
	}
//--------------------------------------------------------------------

	
	
//--------------------------------------------------------------------
/*	public String toString(){
		return String.format( "%d/%d/%d\n", mes, dia, ano );
	}*/
//-----------------------------------------------------------------

	public int getMes(){
		return mes;
	}
	public int getDia(){
		return dia;
	}
	public int getAno(){
		return ano;
	}

//-----------------------------------------------------------------	

	public void incrementDia(){
		if(getDia() < 30){
			dia += 1;
		}
		else{
			dia = 1;
			incrementMes();
		}
	}
	
//-----------------------------------------------------------------	
//a) incrementar para o proximo mes:
	public void incrementMes(){
    if (getMes() < 12)
      mes += 1;
    else{
      mes = 1;
      incrementAno();
      }
    }
	
//-------------------------------------------------------------------
//b) incrementar para o proximo ano;
	public void anoNovo(){
		
	}
	public void incrementAno(){
		ano += 1;
		mes = 01;
		dia = 01;
    }
//-------------------------------------------------------------------

public String toUniversalString(){ 
	return String.format("%d/%d/%d\n",getMes(), getDia(), getAno());
  }
  
  public void imprime(){
  	System.out.printf("%d/%d/%d\n",getMes(), getDia(), getAno());
  }
  
  
  

}