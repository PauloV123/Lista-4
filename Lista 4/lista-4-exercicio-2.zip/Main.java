//Paulo Victor R. Setubal 22117021-0
public class Main{
    public static void main(String[] args) {
    	int i;
    	Data d = new Data(01,01,1999);
    	d.incrementDia();
    	d.toUniversalString();
    	d.imprime();
    	
    	for(i=0;i<2000;i++){ 
    		d.incrementDia();
    		d.toUniversalString();
    		d.imprime();
    		System.out.printf("");
    	}
    	
    	
    }
}

